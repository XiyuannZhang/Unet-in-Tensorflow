

import tensorflow as tf


class ImageCoder(object):

    def __init__(self):

        self._sess = tf.Session()


        self._png_data = tf.placeholder(dtype = tf.string)
        png_image = tf.image.decode_png(self._png_data)
        self._png_to_jpeg = tf.image.encode_jpeg(png_image)


        self._jpeg_data = tf.placeholder(dtype = tf.string)
        jpeg_image = tf.image.decode_jpeg(self._jpeg_data)
        self._jpeg_to_png = tf.image.encode_png(jpeg_image)


        self._decode_jpeg_data = tf.placeholder(dtype = tf.string)
        self._decode_jpeg = tf.image.decode_jpeg(self._decode_jpeg_data)


        self._decode_png_data = tf.placeholder(dtype = tf.string)
        self._decode_png = tf.image.decode_png(self._decode_png_data)


    def is_png(self, filename):


        return filename.lower().endswith(('png'))


    def is_jpeg(self, filename):


        return filename.lower().endswith(('jpg', 'jpeg'))


    def png_to_jpeg(self, image_data):


        return self._sess.run(self._png_to_jpeg,
                             feed_dict={self._png_data: image_data})


    def jpeg_to_png(self, image_data):


        return self._sess.run(self._jpeg_to_png,
                             feed_dict={self._jpeg_data: image_data})


    def decode_jpeg(self, image_data):


        return self._sess.run(self._decode_jpeg,
                             feed_dict={self._decode_jpeg_data: image_data})


    def decode_png(self, image_data):


        return self._sess.run(self._decode_png,
                             feed_dict={self._decode_png_data: image_data})
