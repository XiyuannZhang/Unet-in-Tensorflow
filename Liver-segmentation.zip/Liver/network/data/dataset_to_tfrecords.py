# coding: utf-8
# -*- coding: utf-8 -*-
from __future__ import print_function

import numpy as np
import tensorflow as tf

import argparse
import os
import random
import sys
import threading

from image_coder import *


FLAGS = None


def int64_feature(value):

    if not isinstance(value, list):
        value = [value]
    return tf.train.Feature(int64_list=tf.train.Int64List(value=value))


def bytes_feature(value):

    return tf.train.Feature(bytes_list=tf.train.BytesList(value=[value]))


def convert_to_example(filename, image_buffer, label_buffer, height, width):


    image_format = 'PNG'
    example = tf.train.Example(features=tf.train.Features(feature={
            'image/height': int64_feature(height),
            'image/width': int64_feature(width),
            'image/filename': bytes_feature(tf.compat.as_bytes(os.path.basename(os.path.normpath(filename)))),
            'image/format': bytes_feature(tf.compat.as_bytes(image_format)),
            'image/encoded/color': bytes_feature(tf.compat.as_bytes(image_buffer)),
            'image/encoded/label': bytes_feature(tf.compat.as_bytes(label_buffer))
            }))
    return example


def process_image(filename, coder):

    with tf.gfile.FastGFile(filename, 'rb') as f:
        image_data = f.read()


    if coder.is_jpeg(filename):
        print('[PROGRESS]\tConverting JPEG to PNG for %s' % filename)
        image_data = coder.jpeg_to_png(image_data)

    image = coder.decode_png(image_data)


    assert len(image.shape) == 3
    height = image.shape[0]
    width = image.shape[1]

    if FLAGS.name_color in filename:
        assert image.shape[2] == 3
    else:
        assert image.shape[2] == 1

    return image_data, height, width


def process_image_files_batch(coder, thread_index, ranges, name, filenames, num_shards):

    num_threads = len(ranges)
    assert not num_shards % num_threads
    num_shards_per_batch = int(num_shards / num_threads)

    shard_ranges = np.linspace(ranges[thread_index][0], ranges[thread_index][1],
                               num_shards_per_batch + 1).astype(int)
    num_files_in_thread = ranges[thread_index][1] - ranges[thread_index][0]

    counter = 0
    for s in range(num_shards_per_batch):


        shard = thread_index * num_shards_per_batch + s
        output_filename = '%s-%.5d-of-%.5d.tfrecords' % (name, shard, num_shards)
        output_file = os.path.join(FLAGS.output_dir, output_filename)
        writer = tf.python_io.TFRecordWriter(output_file)

        shard_counter = 0
        files_in_shard = np.arange(shard_ranges[s], shard_ranges[s + 1], dtype=int)
        for i in files_in_shard:
            filename = filenames[i]


            color_file = filename % FLAGS.name_color
            label_file = filename % FLAGS.name_label

            image_buffer, height, width = process_image(color_file, coder)
            label_buffer, height, width = process_image(label_file, coder)

            example = convert_to_example(filename, image_buffer, label_buffer, height, width)
            writer.write(example.SerializeToString())
            shard_counter += 1
            counter += 1

        writer.close()
        print('[THREAD %d]\tWrote %d images to %s' %
                    (thread_index, shard_counter, output_file))
        shard_counter = 0

    print('[THREAD %d]\tWrote %d images to %d shards.' %
                (thread_index, counter, num_files_in_thread))


def process_image_files(name, filenames, num_shards):

    spacing = np.linspace(0, len(filenames), FLAGS.num_threads + 1).astype(np.int)
    ranges = []

    for i in range(len(spacing) - 1):
        ranges.append([spacing[i], spacing[i+1]])

    print('[PROGRESS]\tLaunching %d threads for spacings: %s' % (FLAGS.num_threads, ranges))


    coord = tf.train.Coordinator()


    coder = ImageCoder()

    threads = []
    for thread_index in range(len(ranges)):
        args = (coder, thread_index, ranges, name, filenames, num_shards)
        t = threading.Thread(target=process_image_files_batch, args=args)
        t.start()
        threads.append(t)

    coord.join(threads)
    print('[INFO    ]\tFinished writing all %d images in data set.' % len(filenames))


def find_image_files(data_dir):
    print('[PROGRESS]\tDetermining list of input files from %s' % data_dir)

    filenames = []


    color_file_path = os.path.join(data_dir, '*%s.*') % FLAGS.name_color
    label_file_path = os.path.join(data_dir, '*%s.*') % FLAGS.name_label

    color_files = tf.gfile.Glob(color_file_path)
    label_files = tf.gfile.Glob(label_file_path)
    print (len(color_files), len(label_files))

    assert len(color_files) == len(label_files)

    matching_files = [ x.replace(FLAGS.name_color, '%s') for x in color_files ]

    filenames.extend(matching_files)

    shuffled_index = list(range(len(filenames)))
    random.seed(12345)
    random.shuffle(shuffled_index)

    filenames = [filenames[i] for i in shuffled_index]

    print('[INFO    ]\tFound %d images inside %s.' % (len(filenames), data_dir))

    return filenames


def process_dataset(name, directory, num_shards):


    filenames = find_image_files(directory)
    process_image_files(name, filenames, num_shards)


def main(_):

    assert not FLAGS.num_shards % FLAGS.num_threads, (
            '[ERROR   ]\tPlease make the FLAGS.num_threads commensurate with FLAGS.num_shards')

    print('[INFO    ]\tSaving results to %s' % FLAGS.output_dir)

    if not tf.gfile.Exists(FLAGS.output_dir):
        tf.gfile.MakeDirs(FLAGS.output_dir)

    process_dataset(os.path.basename(os.path.normpath(FLAGS.data_dir)), FLAGS.data_dir,FLAGS.num_shards)


if __name__ == '__main__':

    parser = argparse.ArgumentParser(description = 'Converts image data to TFRecords file format')
    parser.add_argument('--data_dir', help = 'Data directory', default = 'C:\\Users\\apple\Desktop\\network55\\network\Datasets\\test')
    parser.add_argument('--output_dir', help = 'Output data directory', required = False,default = 'C:\\Users\\apple\Desktop\\network55\\network\Datasets\\test')
    parser.add_argument('--num_threads', help = 'Number of threads', type = int, default = 1)
    parser.add_argument('--num_shards', help = 'Number of shards in training TFRecord files', type = int, default = 1)
    parser.add_argument('--name_color', help = 'Color images name format', default = '_color')
    parser.add_argument('--name_label', help = 'Label images name format', default = '_label')
    FLAGS, unparsed = parser.parse_known_args()

    tf.app.run()
